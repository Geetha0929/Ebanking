package com.smartbank.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.smartbank.model.User;
import com.smartbank.dao.UserDao;

public class UserService {
  @	Autowired
  UserDao userDao;
  
  
  private UserDao userDAO;
  
     public String validate(User user)
     {
    	 String s = userDao.validate(user);
    	 return s;
     }

	
}
