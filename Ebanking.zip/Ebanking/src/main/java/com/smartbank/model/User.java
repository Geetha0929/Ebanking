package com.smartbank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="logintable")
public class User {
	public User()
	{
		
		
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer EmpId;
    public Integer getEmpId() {
		return EmpId;
	}

	public void setEmpId(Integer empId) {
		EmpId = empId;
	}

	
   @Column(name="username")
   @NotEmpty(message="username cannot be empty")
	private String uname;
	
   public String getUname() {
	return uname;
}

public void setUname(String uname) {
	this.uname = uname;
}

public String getPwd() {
	return pwd;
}

public void setPwd(String pwd) {
	this.pwd = pwd;
}
@Column(name="password")
   @NotEmpty(message="password cannot be empty ")
	private String pwd;
	}


