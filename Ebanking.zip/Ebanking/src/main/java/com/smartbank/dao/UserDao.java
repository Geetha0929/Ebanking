package com.smartbank.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.hibernate.query.Query;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.smartbank.model.User;

public class UserDao {
     @Autowired
     
     private SessionFactory sessionFactory;
     
     public String validate(User user){
    	 //User user1 = null;
    	 Session session = sessionFactory.openSession();
    	 String hql = "from logintable where uname=:unam and pwd=:password";
    	Query query =session.createQuery(hql);
    	query.setParameter("unam", user.getUname());
    	query.setParameter("password", user.getPwd());
    	
    	
    	 List list = query.getResultList();
    	
    	 if(list.size()==0)
    		 return "failure";
    	 else 
    		 return "success";
    	
    	
    	  }
 }
